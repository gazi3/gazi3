create table Empleado(



NumeroEmpleado int primary key identity NOT NULL,
Nombre varchar NOT NULL,
ApellidoPaterno varchar  NOT NULL,
ApellidoMaterno varchar  NOT NULL,
FechaNacimiento datetime  NOT NULL,
RFC varchar  NOT NULL,
CentroTrabajo varchar  NOT NULL,
Puesto varchar  NOT NULL,
DescripcionPuesto varchar  NOT NULL,
Directivo varchar  NOT NULL


);



CREATE TABLE Puesto(
NumeroPuesto int primary key identity NOT NULL,
Puesto varchar NOT NULL,
DescripcionPuesto varchar NOT NULL,

);

create table CentroTrabajo(
NumeroCentro int primary key identity NOT NULL,
NombreCentro varchar NOT NULL,
Ciudad varchar NOT NULL

);


create table Directivo(
NumeroEmpleado int primary key identity NOT NULL,
NumeroCentroSupervisa varchar NOT NULL,
Prestaciones varchar NOT NULL

);