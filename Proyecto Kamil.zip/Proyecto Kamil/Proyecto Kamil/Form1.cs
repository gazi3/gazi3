﻿using Proyecto_Kamil.KamilDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Kamil
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Conexion.conectar();
            MessageBox.Show("Conexion Exitosa");

            DataGridview1.DataSourse = llenar_grid();
            
          0  
        public DataTable llenar_grid();
            {
                Conexion.conectar();
                DataTable dt = new DataTable();
                string cosulta = "SELECT * FROM Empleado";
                SqlCommand cmd = new SqlCommand(Consulta, Conexion.conectar());


                SqlDataAdapter da = new SqlDataAdapter();

                da.Fill(dt);

                return ;

                {
                    private void button1_Click(object sender, EventArgs e)
                    {
                        Conexion.conectar();
                        string insertar = "INSERT INTO Empleado (NumeroEmpleado,Nombre,ApellidoPaterno,ApellidoMaterno,FechaNAcimiento,RFC,CentroTrabajo,Puesto,DescripcionPuesto,Directivo)VALUES(@NumeroEmpleado, @Nombre, @ApellidoPaterno, @ApellidoMaterno, @FechaNacimiento, @RFC, @CentroTrabajo, @Puesto, @DescripcionPuesto, @Directivo)";
                        SqlCommand cmd1 = new SqlCommand(insertar, Conexion.conectar());
                        cmd1.Parameters.AddWithValue("@NumeroEmpleado", txtNumeroEmpleado.Text);
                        cmd1.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                        cmd1.Parameters.AddWithValue("@Apellido", txtApellidoPaterno.Text);
                        cmd1.Parameters.AddWithValue("@ApellidoMAterno", texApellidoMaterno.Text);
                        cmd1.Parameters.AddWithValue("@FechaNacimiento", txtFechaNacimiento.Text);
                        cmd1.Parameters.AddWithValue(@"RFC", txtRFC.Text);
                        cmd1.Parameters.AddWithValue("@CentroTrabajo", txtCentroTrabajo.Text);
                        cmd1.Parameters.AddWithValue("@Puesto", txtPuesto.Text);
                        cmd1.Parameters.AddWithValue("@DescripcionPuesto", txtDescripcionPuesto.Text);
                        cmd1.Parameters.AddWithValue("@Directivo", txtDirectivo.Text);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Los datos fueron agrgados con exito");
                        DataGridView1.DataSource = llenar_grid();



                   
                        

                    }

                    private void button2_Click(object sender, EventArgs e)
                    {
                        //instancia del formulario Empleado
                        Form2Empleado form = new Form2Empleado();
                        form.ShowDialog();

                    }

                    private void button3_Click(object sender, EventArgs e)
                    {
                        //instancia del formulario Directivo
                        Form2Directivo form = new Form2Directivo();
                        form.ShowDialog();

                    }

                    private void button4_Click(object sender, EventArgs e)
                    {
                        //instancia del formulario Directivo
                        Form2Directivo form = new Form2Directivo();
                        form.ShowDialog();

                    }

                    private void button5_Click(object sender, EventArgs e)
                    {
                        //instancia del formulario Centro
                        Form2Centro form = new Form2Centro();
                        form.ShowDialog();

                    }

                    private void button6_Click(object sender, EventArgs e)
                    {
                        //instancia del formulario centro
                        Form2Centro form = new Form2Centro();
                        form.ShowDialog();
                    }
                }

            }

        
        }


    }
    
    
}
        
    
