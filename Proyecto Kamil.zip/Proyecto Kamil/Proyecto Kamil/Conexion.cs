﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace Proyecto_Kamil
{
    class Conexion
    {
        public static SqlConnection conectar()
        {
            SqlConnection cn = new SqlConnection("SERVER=DESKTOP-BE5BLTQ\\SQLEXPRESS;DATABASE=ProyectoKamil;integrated security=true;");
            cn.Open();

            return cn;
        }


    }

}