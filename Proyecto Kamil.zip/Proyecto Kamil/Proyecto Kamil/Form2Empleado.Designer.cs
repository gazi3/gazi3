﻿using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System;

namespace Proyecto_Kamil
{
    partial class Form2Empleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(188, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(173, 20);
            this.textBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Numero de Empleado";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nombre ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Apellido Paterno";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(50, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Apellido Materno";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Fecha de Nacimiento";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(485, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "RFC";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(485, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Puesto";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(485, 86);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Centro de Trabajo";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(485, 136);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Descripcion del Puesto";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(485, 159);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Directivo";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(188, 133);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(173, 20);
            this.textBox2.TabIndex = 11;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(188, 109);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(173, 20);
            this.textBox3.TabIndex = 12;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(188, 83);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(173, 20);
            this.textBox4.TabIndex = 13;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(188, 55);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(173, 20);
            this.textBox5.TabIndex = 14;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(606, 83);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(182, 20);
            this.textBox6.TabIndex = 15;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(606, 55);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(182, 20);
            this.textBox7.TabIndex = 16;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(606, 135);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(182, 20);
            this.textBox8.TabIndex = 17;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(606, 109);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(182, 20);
            this.textBox9.TabIndex = 18;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(606, 161);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(182, 20);
            this.textBox10.TabIndex = 19;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(385, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 20;
            this.button1.Text = "Buscar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(470, 214);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 21;
            this.button2.Text = "Guardar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(573, 214);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 22;
            this.button3.Text = "Modificar";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(691, 214);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 23;
            this.button4.Text = "Borrar";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // Form2Empleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form2Empleado";
            this.Text = "Form2Empleado";
            this.Load += new System.EventHandler(this.Form2Empleado_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
    {
    public partial class FormEmpleado : Form
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader dr;

        public FormEmpleado()
        {
            InitializeComponent();
        }

        private void FormEmpleado_Load(object sender, EventArgs e)
        {
            cn = new SqlConnection(@"Data Source=(local);Initial Catalog=Kamil;Integrated Security=True");
            cn.Open();
            //bind data in data grid view  
            ObtenerEmpleados();

            //disable delete and update button on load  
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;


            cn = new SqlConnection(@"Data Source=(local);Initial Catalog=Kamil;Integrated Security=True");
            cn.Open();

            SqlDataAdapter sda = new SqlDataAdapter("SELECT Centro, Nombre FROM Centro_Trabajo", cn);

            //Fill the DataTable with records from Table.
            DataTable dt = new DataTable();
            sda.Fill(dt);

            //Insert the Default Item to DataTable.
            DataRow row = dt.NewRow();
            row[0] = 0;
            row[1] = "Please select";
            dt.Rows.InsertAt(row, 0);

            //Assign DataTable as DataSource.
            cbCentroTrabajo.DataSource = dt;
            cbCentroTrabajo.DisplayMember = "Nombre_centro";
            cbCentroTrabajo.ValueMember = "Centro";

            SqlDataAdapter sda_puesto = new SqlDataAdapter("SELECT Puesto, Descripcion FROM Puesto", cn);

            //Fill the DataTable with records from Table.
            DataTable dt_puesto = new DataTable();
            sda_puesto.Fill(dt_puesto);

            //Insert the Default Item to DataTable.
            DataRow row_puesto = dt_puesto.NewRow();
            row_puesto[0] = 0;
            row_puesto[1] = "Please select";
            dt_puesto.Rows.InsertAt(row_puesto, 0);

            //Assign DataTable as DataSource.
            cbPuesto.DataSource = dt_puesto;
            cbPuesto.DisplayMember = "Descripcion";
            cbPuesto.ValueMember = "Puesto";
        }

        private void ObtenerEmpleados()
        {
            SqlCommand cmd = new SqlCommand("Empleados", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Empleaddo", 0);
            cmd.Parameters.AddWithValue("@Nombre", "");
            cmd.Parameters.AddWithValue("@Apellidopaterno", "");
            cmd.Parameters.AddWithValue("@Apellidomaterno", "");
            cmd.Parameters.AddWithValue("@Fec_Nac", "");
            cmd.Parameters.AddWithValue("@Rfc", "");
            cmd.Parameters.AddWithValue("@Centro", 0);
            cmd.Parameters.AddWithValue("@Puesto", "");
            cmd.Parameters.AddWithValue("@Directivo", 0);
            cmd.Parameters.AddWithValue("@OperationType", "5");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgvEmpleados.DataSource = dt;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (txtbNumero.Text != String.Empty && txtbNombre.Text != String.Empty && txtbAPaterno.Text != String.Empty && txtbAMaterno.Text != String.Empty && txtbAMaterno.Text != String.Empty && txtbFechaNacimiento.Text != String.Empty && txtbRfc.Text != String.Empty && cbCentroTrabajo.Text != String.Empty && cbPuesto.Text != string.Empty && txtbDirectivo.Text != String.Empty)
            {
                cmd = new SqlCommand("Empleados", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                string sqlquery = "INSERT INTO Empleados (Empleaddo, Nombre, Apellidopaterno, Apellidomaterno, Fec_Nac, Rfc, Centro, Puesto, Directivo) VALUES (@Empleaddo, @Nombre, @Apellidopaterno, @Apellidomaterno, @Fec_Nac, @Rfc, @Centro, @Puesto, @Directivo)";
                cmd = new SqlCommand(sqlquery, cn);
                cmd.Parameters.AddWithValue("@Empleaddo", txtbNumero.Text);
                cmd.Parameters.AddWithValue("@Nombre", txtbNombre.Text);
                cmd.Parameters.AddWithValue("@Apellidopaterno", txtbAPaterno.Text);
                cmd.Parameters.AddWithValue("@Apellidomaterno", txtbAMaterno);
                cmd.Parameters.AddWithValue("@Fec_Nac", txtbFechaNacimiento.Text);
                cmd.Parameters.AddWithValue("@Rfc", txtbRfc.Text);
                cmd.Parameters.AddWithValue("@Centro", cbCentroTrabajo.Text);
                cmd.Parameters.AddWithValue("@Puesto", cbPuesto.Text);
                cmd.Parameters.AddWithValue("@Directivo", txtbDirectivo.Text);
                cmd.Parameters.AddWithValue("@OperationType", "1");
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record inserted successfully.", "Record Inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ObtenerEmpleados();
                txtbNumero.Text = "";
                txtbNombre.Text = "";
                txtbAPaterno.Text = "";
                txtbAMaterno.Text = "";
                txtbFechaNacimiento.Text = "";
                txtbRfc.Text = "";
                cbCentroTrabajo.Text = "";
                cbPuesto.Text = "";
                txtbDirectivo.Text = "";

            }
            else
            {
                MessageBox.Show("Please enter value in all fields", "Invalid Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (txtbNumero.Text != string.Empty)
            {

                cmd = new SqlCommand("Empleados", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Empleaddo", txtbNumero.Text);
                cmd.Parameters.AddWithValue("@Nombre", "");
                cmd.Parameters.AddWithValue("@Apellidopaterno", "");
                cmd.Parameters.AddWithValue("@Apellidomaterno", "");
                cmd.Parameters.AddWithValue("@Fec_Nac", "");
                cmd.Parameters.AddWithValue("@Rfc", "");
                cmd.Parameters.AddWithValue("@Centro", 0);
                cmd.Parameters.AddWithValue("@Puesto", "");
                cmd.Parameters.AddWithValue("@Directivo", 0);
                cmd.Parameters.AddWithValue("@OperationType", "4");
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtbNombre.Text = dr["Nombre"].ToString();
                    txtbAPaterno.Text = dr["Apellidopaterno"].ToString();
                    txtbAMaterno.Text = dr["Apellidomaterno"].ToString();
                    txtbFechaNacimiento.Text = dr["Fec_Nac"].ToString();
                    txtbRfc.Text = dr["Rfc"].ToString();
                    cbCentroTrabajo.Text = dr["Centro"].ToString();
                    cbPuesto.Text = dr["Puesto"].ToString();
                    txtbDirectivo.Text = dr["Directivo"].ToString();
                    btnModificar.Enabled = true;
                    btnEliminar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No record found with this id", "No Data Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                dr.Close();
            }
            else
            {
                MessageBox.Show("Please enter Center id ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (txtbNumero.Text != String.Empty && txtbNombre.Text != String.Empty && txtbAPaterno.Text != String.Empty && txtbAMaterno.Text != String.Empty && txtbAMaterno.Text != String.Empty && txtbFechaNacimiento.Text != String.Empty && txtbRfc.Text != String.Empty && cbCentroTrabajo.Text != String.Empty && cbPuesto.Text != string.Empty && txtbDirectivo.Text != String.Empty)
            {
                cmd = new SqlCommand("Empleados", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Empleaddo", txtbNumero.Text);
                cmd.Parameters.AddWithValue("@Nombre", txtbNombre.Text);
                cmd.Parameters.AddWithValue("@Apellidopaterno", txtbAPaterno.Text);
                cmd.Parameters.AddWithValue("@Apellidomaerno", txtbAMaterno);
                cmd.Parameters.AddWithValue("@Fec_Nac", txtbFechaNacimiento.Text);
                cmd.Parameters.AddWithValue("@Rfc", txtbRfc.Text);
                cmd.Parameters.AddWithValue("@Centro", cbCentroTrabajo.Text);
                cmd.Parameters.AddWithValue("@Puesto", cbPuesto.Text);
                cmd.Parameters.AddWithValue("@Directivo", txtbDirectivo.Text);
                cmd.Parameters.AddWithValue("@OperationType", "2");
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record update successfully.", "Record Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ObtenerEmpleados();
                btnEliminar.Enabled = false;
                btnModificar.Enabled = false;
            }
            else
            {
                MessageBox.Show("Please enter value in all fields", "Invalid Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (txtbNumero.Text != string.Empty)
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this Center ? ", "Delete Center", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                if (dialogResult == DialogResult.Yes)
                {

                    cmd = new SqlCommand("Empleados", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Empleaddo", txtbNumero.Text);
                    cmd.Parameters.AddWithValue("@Nombre", "");
                    cmd.Parameters.AddWithValue("@Apellidopaterno", "");
                    cmd.Parameters.AddWithValue("@Apellidomaterno", "");
                    cmd.Parameters.AddWithValue("@Fec_Nac", "");
                    cmd.Parameters.AddWithValue("@Rfc", "");
                    cmd.Parameters.AddWithValue("@Centro", 0);
                    cmd.Parameters.AddWithValue("@Puesto", "");
                    cmd.Parameters.AddWithValue("@Directivo", 0);
                    cmd.Parameters.AddWithValue("@OperationType", "3");
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record deleted successfully.", "Record Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ObtenerEmpleados();
                    txtbNumero.Text = "";
                    txtbNombre.Text = "";
                    txtbAPaterno.Text = "";
                    txtbAMaterno.Text = "";
                    txtbFechaNacimiento.Text = "";
                    txtbRfc.Text = "";
                    cbCentroTrabajo.Text = "";
                    cbPuesto.Text = "";
                    txtbDirectivo.Text = "";
                    btnEliminar.Enabled = false;
                    btnModificar.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("Please enter Center id", "Invalid Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
}
