USE Empleados1

CREATE TABLE Empleado1 (
    NumeroEmpleado VARCHAR(40) NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    ApellidoPaterno VARCHAR(100) NOT NULL,
    ApellidoMaterno VARCHAR(100) NOT NULL,
    FechaNacimiento DATETIME NOT NULL,
	RFC VARCHAR(15) NOT NULL,
    CentroTrabajo NUMERIC(20) NOT NULL,
	NombreCentro VARCHAR(100) NOT NULL,
	Ciudad VARCHAR(100) NOT NULL,
    DescripcionPuesto VARCHAR(200),
    Directivo TINYINT CHECK (Directivo IN (0, 1)) NOT NULL,
	
	);
 DECLARE @rfc NVARCHAR(13)